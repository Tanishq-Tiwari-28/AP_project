package com.mygdx.game;
import screens.landingpage;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
public class tankstars extends Game {
	private OrthographicCamera camera;
	private Vector3 mouse;
	public SpriteBatch batch;
	public BitmapFont font;
	public static final float WIDTH = 1280;
	public static final float HEIGTH = 720;

	@Override
	public void create() {
		batch = new SpriteBatch();
		camera = new OrthographicCamera();
		this.setScreen(new landingpage(this));
	}

	@Override
	public void render() {
		super.render();

	}

	@Override
	public void dispose() {
		super.dispose();
	}
}