package screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.tankstars;

import static java.lang.System.exit;

public class mainpage implements Screen {
    private Texture background;
    private TextureRegion backgroundTexture;
    private OrthographicCamera camera;
    private Vector3 mouse;
    final  tankstars game;
    private Stage stage;
    private Viewport view;
    private TextButton new_game;
    private TextButton load_game;
    private TextButton exit_game;
    private TextButton settings;
    private Skin skins;

    public mainpage(tankstars game) {
        this.game=game;
        skins = new Skin(Gdx.files.internal("gdx-skins-master/orange/skin/uiskin.json"));
        background = new Texture(Gdx.files.internal("mainpage.jpeg"));
        camera = new OrthographicCamera();
        view = new FitViewport(1280, 720);
        stage = new Stage(view);



    }

    @Override
    public void show() {
        new_game= new TextButton("Start Game",skins);
        load_game= new TextButton("load Game",skins);
        exit_game= new TextButton("Exit Game",skins);
        settings= new TextButton("Settings",skins);
        stage.addActor(new_game);
        stage.addActor(load_game);
        stage.addActor(settings);
        stage.addActor(exit_game);
        new_game.setPosition(850,500);
        new_game.setSize(200,60);
        load_game.setPosition(850,350);
        load_game.setSize(200,60);
        settings.setPosition(850,200);
        settings.setSize(200,60);
        exit_game.setPosition(850,50);
        exit_game.setSize(200,60);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        Gdx.input.setInputProcessor(stage);
        game.batch.begin();

        game.batch.draw(background,0,0, tankstars.WIDTH, tankstars.HEIGTH);
        new_game.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new choosetank(game));
            }
        });
        load_game.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new loadscreen(game));
            }
        });

        settings.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new settingscreen(game));
            }
        });
        exit_game.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                exit(1);
            }
        });

        game.batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
