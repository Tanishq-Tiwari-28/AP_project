package screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.tankstars;

public class playscreen implements Screen {
    private OrthographicCamera camera;
    private Texture background;
    private TextureRegion backgroundTexture;
    private Vector3 mouse;
    private Stage stage;
    private Viewport view;
    private Skin skins;
    private ImageButton back;
    private TextureRegion textureRegion;
    private TextureRegionDrawable textureRegionDrawable;

    final tankstars game;
    public playscreen(tankstars game) {
        this.game=game;
        camera = new OrthographicCamera();
        background = new Texture(Gdx.files.internal("playpage.jpg"));
        view = new FitViewport(1280, 720);
        stage = new Stage(view);
        skins = new Skin(Gdx.files.internal("gdx-skins-master/orange/skin/uiskin.json"));


    }

    @Override
    public void show() {
        Texture back_img = new Texture(Gdx.files.internal("back_button.png"));
        textureRegion= new TextureRegion(back_img);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        back = new ImageButton(textureRegionDrawable);
        stage.addActor(back);
        back.setPosition(10,650);
        back.setSize(50,50);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        Gdx.input.setInputProcessor(stage);
        game.batch.begin();
        game.batch.draw(background,0,0, tankstars.WIDTH, tankstars.HEIGTH);
        back.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new mainpage(game));
            }
        });
        game.batch.end();
        stage.act();
        stage.draw();
    }


    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
