package screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.tankstars;

public class loadscreen implements Screen {
    private Texture background;

    private ImageButton back;
    private TextureRegion textureRegion;
    private TextureRegionDrawable textureRegionDrawable;
    private Texture saved1;
    private Texture saved2;
    private Texture saved3;
    private ImageButton savedgame_snapshot;
    private TextureRegion backgroundTexture;
    private OrthographicCamera camera;
    private Vector3 mouse;
    final tankstars game;
    private Stage stage;
    private Viewport view;
    private Skin skins;
    private BitmapFont font;
    public loadscreen(tankstars game) {
        this.game=game;
        skins = new Skin(Gdx.files.internal("gdx-skins-master/orange/skin/uiskin.json"));
        background = new Texture(Gdx.files.internal("back2.png"));
        saved1 = new Texture((Gdx.files.internal("savedgame_back.jpeg")));

        camera = new OrthographicCamera();
        BitmapFont font = new BitmapFont();
        view = new FitViewport(1280, 720);
        stage = new Stage(view);
    }

    @Override
    public void show() {
        Texture back_img = new Texture(Gdx.files.internal("back_button.png"));
        textureRegion= new TextureRegion(back_img);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        back = new ImageButton(textureRegionDrawable);
        stage.addActor(back);
        back.setPosition(10,650);
        back.setSize(50,50);
        Texture snap = new Texture(Gdx.files.internal("savedgame.jpeg"));
        textureRegion= new TextureRegion(snap);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        savedgame_snapshot = new ImageButton(textureRegionDrawable);
        stage.addActor(savedgame_snapshot);
        savedgame_snapshot.setPosition(150,425);
        savedgame_snapshot.setSize(tankstars.WIDTH/4, tankstars.HEIGTH/4);


        Texture snap2 = new Texture(Gdx.files.internal("savedgame.jpeg"));
        textureRegion= new TextureRegion(snap2);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        savedgame_snapshot = new ImageButton(textureRegionDrawable);
        stage.addActor(savedgame_snapshot);
        savedgame_snapshot.setPosition(150,75);
        savedgame_snapshot.setSize(tankstars.WIDTH/4, tankstars.HEIGTH/4);


        Texture snap3 = new Texture(Gdx.files.internal("savedgame.jpeg"));
        textureRegion= new TextureRegion(snap3);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        savedgame_snapshot = new ImageButton(textureRegionDrawable);
        stage.addActor(savedgame_snapshot);
        savedgame_snapshot.setPosition(800,425);
        savedgame_snapshot.setSize(tankstars.WIDTH/4, tankstars.HEIGTH/4);


        Texture snap4 = new Texture(Gdx.files.internal("savedgame.jpeg"));
        textureRegion= new TextureRegion(snap4);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        savedgame_snapshot = new ImageButton(textureRegionDrawable);
        stage.addActor(savedgame_snapshot);
        savedgame_snapshot.setPosition(800,75);
        savedgame_snapshot.setSize(tankstars.WIDTH/4, tankstars.HEIGTH/4);

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();

        game.batch.draw(background,0,0, tankstars.WIDTH, tankstars.HEIGTH);
        //game.font.draw(game.batch, "SAVED GAMES",640,700);
        game.batch.draw(saved1,100,400, tankstars.WIDTH/3, tankstars.HEIGTH/3);
        game.batch.draw(saved1,100,50, tankstars.WIDTH/3, tankstars.HEIGTH/3);
        game.batch.draw(saved1,750,400, tankstars.WIDTH/3, tankstars.HEIGTH/3);
        game.batch.draw(saved1,750,50, tankstars.WIDTH/3, tankstars.HEIGTH/3);
        back.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new mainpage(game));
            }
        });
        game.batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
