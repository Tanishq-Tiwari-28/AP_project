package screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g3d.utils.TextureBinder;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.tankstars;

public class choosetank implements Screen {
    private Texture background;
    private TextureRegion backgroundTexture;
    private OrthographicCamera camera;
    private Vector3 mouse;
    final  tankstars game;
    private Stage stage;
    private Viewport view;
    private ImageButton back;
    private TextureRegion textureRegion;
    private Texture tank1;
    private TextureRegionDrawable textureRegionDrawable;
    private TextButton play;
    private Skin skins;
    public choosetank(tankstars game) {
        this.game=game;
        skins = new Skin(Gdx.files.internal("gdx-skins-master/orange/skin/uiskin.json"));
        background = new Texture(Gdx.files.internal("choosetank.jpg"));
        tank1 = new Texture(Gdx.files.internal("tank.png"));
        camera = new OrthographicCamera();
        view = new FitViewport(1280, 720);
        stage = new Stage(view);
    }

    @Override
    public void show() {
        play = new TextButton("Play Game",skins);
        stage.addActor(play);
        play.setPosition(900,100);
        play.setSize(200,60);
        Texture back_img = new Texture(Gdx.files.internal("back_button.png"));
        textureRegion= new TextureRegion(back_img);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        back = new ImageButton(textureRegionDrawable);
        stage.addActor(back);
        back.setPosition(10,650);
        back.setSize(50,50);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        Gdx.input.setInputProcessor(stage);
        game.batch.begin();
        game.batch.draw(background,0,0, tankstars.WIDTH, tankstars.HEIGTH);
        game.batch.draw(tank1,800,200, tankstars.WIDTH/3, tankstars.HEIGTH/3);
        play.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new playscreen(game));
            }
        });
        game.batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
