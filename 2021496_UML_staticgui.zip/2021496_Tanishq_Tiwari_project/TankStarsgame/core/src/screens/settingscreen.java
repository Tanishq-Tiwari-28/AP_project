package screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.tankstars;
import org.w3c.dom.Text;

public class settingscreen implements Screen {
    private Texture background;
    private ImageButton back;
    private TextureRegion textureRegion;
    private TextureRegionDrawable textureRegionDrawable;
    private OrthographicCamera camera;
    private Vector3 mouse;
    final tankstars game;
    private Stage stage;
    private Viewport view;
    private Texture saved1;
    private Skin skins;
    private BitmapFont font;
    private TextButton music;
    private TextButton vibration;
    private TextButton notification;
    private TextButton policy;
    public settingscreen(tankstars game) {
        this.game=game;
        skins = new Skin(Gdx.files.internal("gdx-skins-master/orange/skin/uiskin.json"));
        background = new Texture(Gdx.files.internal("back3.png"));
        saved1 = new Texture((Gdx.files.internal("savedgame_back.jpeg")));
        camera = new OrthographicCamera();
        BitmapFont font = new BitmapFont();
        view = new FitViewport(1280, 720);
        stage = new Stage(view);

    }

    @Override
    public void show() {
        music= new TextButton("Music ON/OFF",skins);
        notification= new TextButton("Notification ON/OFF",skins);
        policy= new TextButton("Terms and conditions",skins);
        vibration= new TextButton("Vibrations ON/OFF",skins);
        stage.addActor(music);
        stage.addActor(notification);
        stage.addActor(vibration);
        stage.addActor(policy);
        music.setPosition(550,520);
        music.setSize(160,87);
        notification.setPosition(560,380);
        notification.setSize(180,87);
        vibration.setPosition(550,240);
        vibration.setSize(160,87);
        policy.setPosition(550,100);
        policy.setSize(160,87);
        Texture back_img = new Texture(Gdx.files.internal("back_button.png"));
        textureRegion= new TextureRegion(back_img);
        textureRegionDrawable = new TextureRegionDrawable(textureRegion);
        back = new ImageButton(textureRegionDrawable);
        stage.addActor(back);
        back.setPosition(10,650);
        back.setSize(50,50);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();

        game.batch.draw(background,0,0, tankstars.WIDTH, tankstars.HEIGTH);
        game.batch.draw(saved1, 480, 90, tankstars.WIDTH-960,tankstars.HEIGTH-180);
        back.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new mainpage(game));
            }
        });
        game.batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
